Rails.application.routes.draw do
  resources :jobs
  root 'jobs#index'
  get "sign_up" => "users#new", :as => "sign_up"
  get "login" => "sessions#new", :as => "login"

  get "/jobs_users/:id/accepted"=>"jobs_users#accepted",:as => "accepted"
  get "/jobs_users/:id/rejected"=>"jobs_users#rejected",:as => "rejected"
  get "/list_applyment/"=>"jobs_users#list_applyment",:as => "list_applyment"
 
  resources :users
  resources :sessions
  resources :jobs_users, :only => [:destroy, :index, :edit]
  resources :jobs do
    resources :jobs_users, :only => [:create, :new]
  end

  get "/users/:id/applyment"=>"users#applyment",:as => "applyment"
  resources :users do
    resources :jobs_users
  end
  # get 'users/index'
  # get 'users/new'
  # get 'users/edit'
  # get 'jobs/index'
  # get 'jobs/new'S
  # get 'jobs/edit'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
