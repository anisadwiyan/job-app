class ChangeResumeToJobsUsers < ActiveRecord::Migration[5.2]
  def change
  	change_column :jobs_users, :resume, :string
  	rename_column :jobs_users, :resume, :attachment
  end
end
