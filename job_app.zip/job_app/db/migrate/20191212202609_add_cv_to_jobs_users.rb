class AddCvToJobsUsers < ActiveRecord::Migration[5.2]
  def change
    add_column :jobs_users, :cv, :string
  end
end
