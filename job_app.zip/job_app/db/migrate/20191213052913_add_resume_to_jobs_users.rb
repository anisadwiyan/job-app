class AddResumeToJobsUsers < ActiveRecord::Migration[5.2]
  def change
    add_column :jobs_users, :resume, :json
  end
end
