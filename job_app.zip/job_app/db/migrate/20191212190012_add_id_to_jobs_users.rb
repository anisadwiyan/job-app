class AddIdToJobsUsers < ActiveRecord::Migration[5.2]
  def change
  	 add_column :jobs_users, :job_id, :integer
     add_column :jobs_users, :user_id, :integer
  end
end
