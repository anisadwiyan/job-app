class RemoveCvToJobsUsers < ActiveRecord::Migration[5.2]
  def change
  	remove_column :jobs_users, :cv
  end
end
