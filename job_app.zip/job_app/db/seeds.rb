# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

Job.create([
	{title: 'Front-end Developer', description: 'Membuat aplikasi frontend (yang diakses oleh user) berbasis HTML, CSS dan JAVASCRIPT dan menampilkan data-data yang diberikan melalui REST API dalam bentuk paragraf, formulir, grafik, atau tabel', skill: 'JavaScript, Vue.js, Html5, Css3, JSON'},
	{title: 'Interior Designer', description: 'Designing Corporate/ Workplace interior projects . Working closely with a Senior Designer and other team members, you will support Sketchup design approaches and develop project design and presentation drawings', skill: '3D Modeling, AutoCAD, Adobe Photoshop'},
	{title: 'Astronot', description: 'Going to the space (especially moon), make new discovery and research and also looking for the aliens to continue Hawking''s project', skill: 'astronomy, not an Einstein term'},
])