require 'test_helper'

class ConfirmationMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
