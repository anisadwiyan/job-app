class JobsUser < ActiveRecord::Base

	mount_uploader :attachment, AttachmentUploader # Tells rails to use this uploader for this model.
	validates :cover_letter, presence: true # Make sure the owner's name is present.
	def default_status
		self.status = "unread"
		self.user_id = 1
		self.job_id = 1
	end
end
