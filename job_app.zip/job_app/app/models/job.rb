class Job < ActiveRecord::Base

  has_many :jobs_users
  has_many :users, through: :jobs_users

end
