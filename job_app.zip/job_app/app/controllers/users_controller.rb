class UsersController < ApplicationController
  def show
  	@users= User.find_by_id(params[:id])	
  end

  def applyment
    @users= JobsUser.find_by_id(params[:id])  
  end

  def new
  	@user= User.new
  end

  def edit
  end

  def create
  	@user = User.new(params_user)
      if @user.save
        ConfirmationMailer.confirm_email(@user).deliver
        flash[:notice] = "Activation instruction has been sent to#{@user.email}"
        redirect_to root_url
    else
        flash[:error] = "data not valid"
        render "new"
    end
  end

  private
  def params_user
     params.require(:user).permit(:name, :birth, :username, :email, :password, :password_confirmation, :humanizer_answer, :humanizer_question_id)
  end
end
