class ConfirmationMailer < ApplicationMailer
	def confirm_email(user)
		@user = user
        mail to:user.email, 
        	 subject:"Teh Pia udah bisaa, makasihh <3",
        	 body:"http://localhost:3000/sessions/#{user.activation_token}/edit",
        	 content_type:"text/html",
        	 template_path:"confirmation_mailer",
        	 template_name:"confirm_email"
   
    end
end
